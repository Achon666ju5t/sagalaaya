
            require("MRenderingScheduler").getInstance().schedule({
                "id": "pagelet_0_0",
                "pageletConfig": {
                    "lid": "6589638692853231387-60001",
                    "serverlid": "6589638692853231387-0",
                    "name": "pagelet_0_0",
                    "pass": 4,
                    "serverJSData": [],
                    "onload": "",
                    "onafterload": "",
                    "scheduledMarkupIndex": 0,
                    "templateContainer": "static_templates",
                    "templates": {
                        "__html": ""
                    },
                    "ixData": {},
                    "bxData": {},
                    "gkxData": {},
                    "qexData": {},
                    "resource_map": {},
                    "bootloadable": {},
                    "type": "chrome"
                },
                "displayResources": [],
                "normalResources": [],
                "content": {
                    "__html": ""
                }
            }, function() {
                require("NavigationMetrics").postPagelet(false, "pagelet_0_0", "6589638692853231387-0");
            });