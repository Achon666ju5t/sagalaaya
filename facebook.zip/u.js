
            require("MRenderingScheduler").getInstance().setPageletCount(1);
            require("NavigationMetrics").setPage({
                "page": "\/wap\/index.php",
                "page_type": "normal",
                "page_uri": "https:\/\/m.facebook.com\/",
                "serverLID": "6589638692853231387-0"
            });
            require("TimeSlice").guard(function() {
                (require("ServerJSDefine")).handleDefines([]);
                new(require("ServerJS"))().handle({});
            }, "ServerJS define", {
                "root": true
            })();
            require("TimeSlice").guard(function() {
                (require("ServerJSDefine")).handleDefines([]);
                new(require("ServerJS"))().handle({});
            }, "ServerJS define", {
                "root": true
            })();