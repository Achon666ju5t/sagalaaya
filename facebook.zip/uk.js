
            require("TimeSlice").guard(function() {
                (require("ServerJSDefine")).handleDefines([
                    ["BanzaiRefactored", ["BanzaiOld"], {
                        "module": {
                            "__m": "BanzaiOld"
                        }
                    }, 3421],
                    ["ChannelClientConfig", [], {}, 395],
                    ["BootloaderConfig", [], {
                        "jsRetries": null,
                        "jsRetryAbortNum": 2,
                        "jsRetryAbortTime": 5,
                        "payloadEndpointURI": "https:\/\/m.facebook.com\/ajax\/haste-response\/",
                        "assumeNotNonblocking": false,
                        "assumePermanent": true,
                        "skipEndpoint": true,
                        "staggerJsDownloads": false,
                        "fixMemoryLeaks": false,
                        "webspeed_eager_preloading": false,
                        "preloader_num_preloads": 5,
                        "preloader_preload_after_dd": false,
                        "preloader_num_loads": 1,
                        "preloader_enabled": false
                    }, 329],
                    ["CSSLoaderConfig", [], {
                        "timeout": 5000,
                        "modulePrefix": "BLCSS:",
                        "loadEventSupported": true
                    }, 619],
                    ["ServerNonce", [], {
                        "ServerNonce": "Me5oi97Ogfjxxa6_VjfMs7"
                    }, 141],
                    ["CurrentCommunityInitialData", [], {}, 490],
                    ["CurrentUserInitialData", [], {
                        "USER_ID": "0",
                        "ACCOUNT_ID": "0",
                        "NAME": "",
                        "SHORT_NAME": null,
                        "IS_MESSENGER_ONLY_USER": false,
                        "IS_DEACTIVATED_ALLOWED_ON_MESSENGER": false
                    }, 270],
                    ["MRequestConfig", [], {
                        "dtsg": {
                            "token": "AQFMba6bco6O:AQG5bOy4_936",
                            "valid_for": 86400,
                            "expire": 1534356218
                        },
                        "lsd": "AVpWsy7M",
                        "checkResponseOrigin": true,
                        "checkResponseToken": true,
                        "ajaxResponseToken": {
                            "secret": "gHP8xji5ajKbhHfPGjzkrf4QQ7kbDBxz",
                            "encrypted": "AYk-UbAN_VrmRp3LynQR1ONJRitJP97mi-w_3YZl1qEOvWxlMyurNuWmwk8zNzWEWn_O91XXBiu6h5Uly4Cro51h6zDapZULjr1bBB42NSD6pQ"
                        }
                    }, 51],
                    ["ImmediateImplementationExperiments", [], {
                        "prefer_message_channel": false
                    }, 3419],
                    ["PromiseUsePolyfillSetImmediateGK", [], {
                        "www_always_use_polyfill_setimmediate": false
                    }, 2190],
                    ["SprinkleConfig", [], {
                        "param_name": "jazoest",
                        "version": 2
                    }, 2111],
                    ["ISB", [], {}, 330],
                    ["LSD", [], {
                        "token": "AVpWsy7M"
                    }, 323],
                    ["SiteData", [], {
                        "server_revision": 4207187,
                        "client_revision": 4207187,
                        "tier": "",
                        "push_phase": "C3",
                        "pkg_cohort": "FW_EXP:mtouch_pkg",
                        "pkg_cohort_key": "__pc",
                        "haste_site": "mobile",
                        "be_mode": -1,
                        "be_key": "__be",
                        "is_rtl": false,
                        "vip": "31.13.78.35"
                    }, 317],
                    ["CookieCoreConfig", [], {
                        "a11y": {},
                        "act": {},
                        "c_user": {},
                        "ddid": {
                            "p": "\/deferreddeeplink\/",
                            "t": 2419200
                        },
                        "dpr": {
                            "t": 604800
                        },
                        "js_ver": {
                            "t": 604800
                        },
                        "locale": {
                            "t": 604800
                        },
                        "lh": {
                            "t": 604800
                        },
                        "m_pixel_ratio": {
                            "t": 604800
                        },
                        "noscript": {},
                        "pnl_data2": {
                            "t": 2
                        },
                        "presence": {},
                        "sW": {},
                        "sfau": {},
                        "wd": {
                            "t": 604800
                        },
                        "x-referer": {},
                        "x-src": {
                            "t": 1
                        }
                    }, 2104],
                    ["CookieCoreLoggingConfig", [], {
                        "maximumIgnorableStallMs": 16.67,
                        "sampleRate": 9.7e-5
                    }, 3401],
                    ["KSConfig", [], {
                        "killed": {
                            "__set": ["POCKET_MONSTERS_CREATE", "POCKET_MONSTERS_DELETE", "VIDEO_DIMENSIONS_FROM_PLAYER_IN_UPLOAD_DIALOG", "PREVENT_INFINITE_URL_REDIRECT", "POCKET_MONSTERS_UPDATE_NAME"]
                        }
                    }, 2580],
                    ["UserAgentData", [], {
                        "browserArchitecture": "64",
                        "browserFullVersion": "68.0.3440.75",
                        "browserMinorVersion": 0,
                        "browserName": "Chrome",
                        "browserVersion": 68,
                        "deviceName": "Unknown",
                        "engineName": "WebKit",
                        "engineVersion": "537.36",
                        "platformArchitecture": "64",
                        "platformName": "Linux",
                        "platformVersion": null,
                        "platformFullVersion": null
                    }, 527],
                    ["ZeroRewriteRules", [], {
                        "rewrite_rules": {
                            "m": "m",
                            "mobile": "m"
                        },
                        "whitelist": {
                            "\/hr\/r": 1,
                            "\/hr\/p": 1,
                            "\/zero\/unsupported_browser\/": 1,
                            "\/zero\/policy\/optin": 1,
                            "\/zero\/optin\/write\/": 1,
                            "\/zero\/optin\/legal\/": 1,
                            "\/zero\/optin\/free\/": 1,
                            "\/about\/privacy\/": 1,
                            "\/about\/privacy\/update\/": 1,
                            "\/about\/privacy\/update": 1,
                            "\/zero\/toggle\/welcome\/": 1,
                            "\/work\/landing": 1,
                            "\/work\/login\/": 1,
                            "\/work\/email\/": 1,
                            "\/ai.php": 1,
                            "\/js_dialog_resources\/dialog_descriptions_android.json": 0,
                            "\/connect\/jsdialog\/MPlatformAppInvitesJSDialog\/": 0,
                            "\/connect\/jsdialog\/MPlatformOAuthShimJSDialog\/": 0,
                            "\/connect\/jsdialog\/MPlatformLikeJSDialog\/": 0,
                            "\/qp\/interstitial\/": 1,
                            "\/qp\/action\/redirect\/": 1,
                            "\/qp\/action\/close\/": 1,
                            "\/zero\/support\/ineligible\/": 1,
                            "\/zero_balance_redirect\/": 1,
                            "\/zero_balance_redirect": 1,
                            "\/l.php": 1,
                            "\/lsr.php": 1,
                            "\/ajax\/dtsg\/": 1,
                            "\/checkpoint\/block\/": 1,
                            "\/exitdsite": 1,
                            "\/zero\/balance\/pixel\/": 1,
                            "\/zero\/balance\/": 1,
                            "\/zero\/balance\/carrier_landing\/": 1,
                            "\/zero\/flex\/logging\/": 1,
                            "\/tr": 1,
                            "\/tr\/": 1,
                            "\/sem_campaigns\/sem_pixel_test\/": 1,
                            "\/bookmarks\/flyout\/body\/": 1,
                            "\/zero\/subno\/": 1,
                            "\/confirmemail.php": 1,
                            "\/policies\/": 1,
                            "\/mobile\/internetdotorg\/classifier\/": 1,
                            "\/zero\/dogfooding": 1,
                            "\/xti.php": 1,
                            "\/4oh4.php": 1,
                            "\/autologin.php": 1,
                            "\/birthday_help.php": 1,
                            "\/checkpoint\/": 1,
                            "\/contact-importer\/": 1,
                            "\/cr.php": 1,
                            "\/legal\/terms\/": 1,
                            "\/login.php": 1,
                            "\/login\/": 1,
                            "\/mobile\/account\/": 1,
                            "\/n\/": 1,
                            "\/remote_test_device\/": 1,
                            "\/upsell\/buy\/": 1,
                            "\/upsell\/buyconfirm\/": 1,
                            "\/upsell\/buyresult\/": 1,
                            "\/upsell\/promos\/": 1,
                            "\/upsell\/continue\/": 1,
                            "\/upsell\/h\/promos\/": 1,
                            "\/upsell\/loan\/learnmore\/": 1,
                            "\/upsell\/purchase\/": 1,
                            "\/upsell\/promos\/upgrade\/": 1,
                            "\/upsell\/buy_redirect\/": 1,
                            "\/upsell\/loan\/buyconfirm\/": 1,
                            "\/upsell\/loan\/buy\/": 1,
                            "\/upsell\/sms\/": 1,
                            "\/wap\/a\/channel\/reconnect.php": 1,
                            "\/wap\/a\/nux\/wizard\/nav.php": 1,
                            "\/wap\/appreg.php": 1,
                            "\/wap\/birthday_help.php": 1,
                            "\/wap\/c.php": 1,
                            "\/wap\/confirmemail.php": 1,
                            "\/wap\/cr.php": 1,
                            "\/wap\/login.php": 1,
                            "\/wap\/r.php": 1,
                            "\/zero\/datapolicy": 1,
                            "\/a\/timezone.php": 1,
                            "\/a\/bz": 1,
                            "\/bz\/reliability": 1,
                            "\/r.php": 1,
                            "\/mr\/": 1,
                            "\/reg\/": 1,
                            "\/registration\/log\/": 1,
                            "\/terms\/": 1,
                            "\/f123\/": 1,
                            "\/expert\/": 1,
                            "\/experts\/": 1,
                            "\/terms\/index.php": 1,
                            "\/terms.php": 1,
                            "\/srr\/": 1,
                            "\/msite\/redirect\/": 1,
                            "\/fbs\/pixel\/": 1,
                            "\/contactpoint\/preconfirmation\/": 1,
                            "\/contactpoint\/cliff\/": 1,
                            "\/contactpoint\/confirm\/submit\/": 1,
                            "\/contactpoint\/confirmed\/": 1,
                            "\/contactpoint\/login\/": 1,
                            "\/preconfirmation\/contactpoint_change\/": 1,
                            "\/help\/contact\/": 1,
                            "\/survey\/": 1,
                            "\/upsell\/loyaltytopup\/accept\/": 1,
                            "\/settings\/": 1
                        }
                    }, 1478],
                    ["MJSEnvironment", [], {
                        "IS_APPLE_WEBKIT_IOS": false,
                        "IS_TABLET": false,
                        "IS_ANDROID": false,
                        "IS_CHROME": true,
                        "IS_FIREFOX": false,
                        "IS_WINDOWS_PHONE": false,
                        "IS_SAMSUNG_DEVICE": false,
                        "OS_VERSION": 0,
                        "PIXEL_RATIO": 1,
                        "BROWSER_NAME": "Unknown"
                    }, 46],
                    ["ZeroCategoryHeader", [], {}, 1127],
                    ["MLoadingIndicatorSigils", [], {
                        "ANIMATE": "m-loading-indicator-animate",
                        "ROOT": "m-loading-indicator-root"
                    }, 279],
                    ["FbtLogger", [], {
                        "logger": null
                    }, 288],
                    ["IntlNumberTypeConfig", [], {
                        "impl": "return IntlVariations.NUMBER_OTHER;"
                    }, 3405],
                    ["FbtQTOverrides", [], {
                        "overrides": {}
                    }, 551],
                    ["FbtResultGK", [], {
                        "shouldReturnFbtResult": true,
                        "inlineMode": "NO_INLINE"
                    }, 876],
                    ["IntlHoldoutGK", [], {
                        "inIntlHoldout": false
                    }, 2827],
                    ["IntlViewerContext", [], {
                        "GENDER": 3
                    }, 772],
                    ["NumberFormatConfig", [], {
                        "decimalSeparator": ",",
                        "numberDelimiter": ".",
                        "minDigitsForThousandsSeparator": 4,
                        "standardDecimalPatternInfo": {
                            "primaryGroupSize": 3,
                            "secondaryGroupSize": 3
                        },
                        "numberingSystemData": null
                    }, 54],
                    ["IntlPhonologicalRules", [], {}, 1496],
                    ["MobileAppDetect", [], {
                        "is_mobile_app": false,
                        "is_pages_manager": false,
                        "is_facebook_for_android": false,
                        "is_facebook_for_android_in_app_browser": false,
                        "is_facebook_for_ios": false,
                        "is_messenger_for_android": false,
                        "is_messenger_for_ios": false,
                        "is_wilde": false,
                        "is_kaios": false
                    }, 1109],
                    ["MWebStorageMonsterWhiteList", [], {
                        "whitelist": ["^Banzai$", "^bz", "^mutex", "^msys", "^sp_pi$", "^\\:userchooser\\:osessusers$", "^\\:userchooser\\:settings$", "^[0-9]+:powereditor:", "^Bandicoot\\:", "^brands\\:console\\:config$", "^CacheStorageVersion$", "^consoleEnabled$", "^_video_$", "^vc_", "^_showMDevConsole$", "^_ctv_$", "^ga_client_id$", "^qe_switcher_nub_selection$", "^_mswam_$"]
                    }, 254],
                    ["MTouchableSyntheticClickGK", [], {
                        "USE_SYNTHETIC_CLICK": true
                    }, 368],
                    ["ErrorDebugHooks", [], {
                        "SnapShotHook": null
                    }, 185],
                    ["ArtilleryExperiments", [], {
                        "artillery_static_resources_pagelet_attribution": false,
                        "artillery_timeslice_compressed_data": false,
                        "artillery_miny_client_payload": false,
                        "artillery_prolong_page_tracing": false,
                        "artillery_navigation_timing_level_2": false,
                        "artillery_profiler_on": false,
                        "artillery_merge_max_distance_sec": 1,
                        "artillery_merge_max_duration_sec": 1,
                        "user_timing": false
                    }, 1237],
                    ["TimeSliceInteractionSV", [], {
                        "on_demand_reference_counting": true,
                        "on_demand_profiling_counters": true,
                        "default_rate": 1000,
                        "lite_default_rate": 100,
                        "interaction_to_lite_coinflip": {
                            "ADS_INTERFACES_INTERACTION": 0,
                            "ads_perf_scenario": 0,
                            "ads_wait_time": 0,
                            "Event": 10,
                            "video_psr": 0,
                            "video_stall": 0
                        },
                        "interaction_to_coinflip": {
                            "ADS_INTERFACES_INTERACTION": 1,
                            "ads_perf_scenario": 1,
                            "ads_wait_time": 1,
                            "video_psr": 1000000,
                            "video_stall": 2500000,
                            "Event": 500,
                            "watch_carousel_left_scroll": 1,
                            "watch_carousel_right_scroll": 1,
                            "watch_sections_load_more": 1,
                            "watch_discover_scroll": 1,
                            "fbpkg_ui": 1,
                            "sevmanager_powersearch_initial_page_load": 10,
                            "backbone_ui": 1
                        },
                        "enable_heartbeat": true,
                        "maxBlockMergeDuration": 0,
                        "maxBlockMergeDistance": 0,
                        "enable_banzai_stream": true,
                        "user_timing_coinflip": 50,
                        "banzai_stream_coinflip": 1,
                        "compression_enabled": true,
                        "ref_counting_fix": true,
                        "ref_counting_cont_fix": false,
                        "also_record_new_timeslice_format": false,
                        "force_async_request_tracing_on": false
                    }, 2609],
                    ["FWLoader", [], {}, 278],
                    ["MPageControllerGating", [], {
                        "shouldDeferUntilCertainNoRedirect": false
                    }, 2023],
                    ["CoreWarningGK", [], {
                        "forceWarning": false
                    }, 725],
                    ["BigPipeExperiments", [], {
                        "link_images_to_pagelets": false
                    }, 907],
                    ["ArtilleryComponentSaverOptions", [], {
                        "options": {
                            "ads_wait_time_saver": {
                                "shouldCompress": false,
                                "shouldUploadSeparately": false
                            },
                            "ads_flux_profiler_saver": {
                                "shouldCompress": true,
                                "shouldUploadSeparately": false
                            },
                            "timeslice_execution_saver": {
                                "shouldCompress": true,
                                "shouldUploadSeparately": false
                            },
                            "interaction_async_request_join_data": {
                                "shouldCompress": true,
                                "shouldUploadSeparately": true
                            },
                            "resources_saver": {
                                "shouldCompress": true,
                                "shouldUploadSeparately": false
                            },
                            "user_timing_saver": {
                                "shouldCompress": false,
                                "shouldUploadSeparately": false
                            }
                        }
                    }, 3016],
                    ["MRenderingSchedulerConfig", [], {
                        "delayNormalResources": false,
                        "isDisplayJSEnabled": false
                    }, 1978],
                    ["EventConfig", [], {
                        "sampling": {
                            "bandwidth": 0,
                            "play": 0,
                            "playing": 0,
                            "progress": 0,
                            "pause": 0,
                            "ended": 0,
                            "seeked": 0,
                            "seeking": 0,
                            "waiting": 0,
                            "loadedmetadata": 0,
                            "canplay": 0,
                            "selectionchange": 0,
                            "change": 0,
                            "timeupdate": 2000000,
                            "adaptation": 0,
                            "focus": 0,
                            "blur": 0,
                            "load": 0,
                            "error": 0,
                            "message": 0,
                            "abort": 0,
                            "storage": 0,
                            "scroll": 200000,
                            "mousemove": 20000,
                            "mouseover": 10000,
                            "mouseout": 10000,
                            "mousewheel": 1,
                            "MSPointerMove": 10000,
                            "keydown": 0.1,
                            "click": 0.02,
                            "mouseup": 0.02,
                            "__100ms": 0.001,
                            "__default": 5000,
                            "__min": 100,
                            "__interactionDefault": 200,
                            "__eventDefault": 100000
                        },
                        "page_sampling_boost": 1,
                        "interaction_regexes": {
                            "BlueBarAccountChevronMenu": " _5lxs(?: .*)?$",
                            "BlueBarHomeButton": " _bluebarLinkHome__interaction-root(?: .*)?$",
                            "BlueBarProfileLink": " _1k67(?: .*)?$",
                            "ReactComposerSproutMedia": " _1pnt(?: .*)?$",
                            "ReactComposerSproutAlbum": " _1pnu(?: .*)?$",
                            "ReactComposerSproutNote": " _3-9x(?: .*)?$",
                            "ReactComposerSproutLocation": " _1pnv(?: .*)?$",
                            "ReactComposerSproutActivity": " _1pnz(?: .*)?$",
                            "ReactComposerSproutPeople": " _1pn-(?: .*)?$",
                            "ReactComposerSproutLiveVideo": " _5tv7(?: .*)?$",
                            "ReactComposerSproutMarkdown": " _311p(?: .*)?$",
                            "ReactComposerSproutFormattedText": " _mwg(?: .*)?$",
                            "ReactComposerSproutSticker": " _2vri(?: .*)?$",
                            "ReactComposerSproutSponsor": " _5t5q(?: .*)?$",
                            "ReactComposerSproutEllipsis": " _1gr3(?: .*)?$",
                            "ReactComposerSproutContactYourRepresentative": " _3cnv(?: .*)?$",
                            "ReactComposerSproutFunFact": " _2_xs(?: .*)?$",
                            "TextExposeSeeMoreLink": " see_more_link(?: .*)?$",
                            "SnowliftBigCloseButton": "(?: _xlt(?: .*)? _418x(?: .*)?$| _418x(?: .*)? _xlt(?: .*)?$)",
                            "SnowliftPrevPager": "(?: snowliftPager(?: .*)? prev(?: .*)?$| prev(?: .*)? snowliftPager(?: .*)?$)",
                            "SnowliftNextPager": "(?: snowliftPager(?: .*)? next(?: .*)?$| next(?: .*)? snowliftPager(?: .*)?$)",
                            "SnowliftFullScreenButton": "#fbPhotoSnowliftFullScreenSwitch( .+)*",
                            "PrivacySelectorMenu": "(?: _57di(?: .*)? _2wli(?: .*)?$| _2wli(?: .*)? _57di(?: .*)?$)",
                            "ReactComposerFeedXSprouts": " _nh6(?: .*)?$",
                            "SproutsComposerStatusTab": " _sg1(?: .*)?$",
                            "SproutsComposerLiveVideoTab": " _sg1(?: .*)?$",
                            "SproutsComposerAlbumTab": " _sg1(?: .*)?$",
                            "composerAudienceSelector": " _ej0(?: .*)?$",
                            "FeedHScrollAttachmentsPrevPager": " _1qqy(?: .*)?$",
                            "FeedHScrollAttachmentsNextPager": " _1qqz(?: .*)?$",
                            "DockChatTabFlyout": " fbDockChatTabFlyout(?: .*)?$",
                            "PrivacyLiteJewel": " _59fc(?: .*)?$",
                            "ActorSelector": " _6vh(?: .*)?$",
                            "LegacyMentionsInput": "(?: ReactLegacyMentionsInput(?: .*)? uiMentionsInput(?: .*)? _2xwx(?: .*)?$| uiMentionsInput(?: .*)? ReactLegacyMentionsInput(?: .*)? _2xwx(?: .*)?$| _2xwx(?: .*)? ReactLegacyMentionsInput(?: .*)? uiMentionsInput(?: .*)?$| ReactLegacyMentionsInput(?: .*)? _2xwx(?: .*)? uiMentionsInput(?: .*)?$| uiMentionsInput(?: .*)? _2xwx(?: .*)? ReactLegacyMentionsInput(?: .*)?$| _2xwx(?: .*)? uiMentionsInput(?: .*)? ReactLegacyMentionsInput(?: .*)?$)",
                            "UFIActionLinksEmbedLink": " _2g1w(?: .*)?$",
                            "UFIPhotoAttachLink": " UFIPhotoAttachLinkWrapper(?: .*)?$",
                            "UFIMentionsInputProxy": " _1osa(?: .*)?$",
                            "UFIMentionsInputDummy": " _1osc(?: .*)?$",
                            "UFIOrderingModeSelector": " _3scp(?: .*)?$",
                            "UFIPager": "(?: UFIPagerRow(?: .*)? UFIRow(?: .*)?$| UFIRow(?: .*)? UFIPagerRow(?: .*)?$)",
                            "UFIReplyRow": "(?: UFIReplyRow(?: .*)? UFICommentReply(?: .*)?$| UFICommentReply(?: .*)? UFIReplyRow(?: .*)?$)",
                            "UFIReplySocialSentence": " UFIReplySocialSentenceRow(?: .*)?$",
                            "UFIShareLink": " _5f9b(?: .*)?$",
                            "UFIStickerButton": " UFICommentStickerButton(?: .*)?$",
                            "MentionsInput": " _5yk1(?: .*)?$",
                            "FantaChatTabRoot": " _3_9e(?: .*)?$",
                            "SnowliftViewableRoot": " _2-sx(?: .*)?$",
                            "ReactBlueBarJewelButton": " _5fwr(?: .*)?$",
                            "UFIReactionsDialogLayerImpl": " _1oxk(?: .*)?$",
                            "UFIReactionsLikeLinkImpl": " _4x9_(?: .*)?$",
                            "UFIReactionsLinkImplRoot": " _khz(?: .*)?$",
                            "Reaction": " _iuw(?: .*)?$",
                            "UFIReactionsMenuImpl": " _iu-(?: .*)?$",
                            "UFIReactionsSpatialReactionIconContainer": " _1fq9(?: .*)?$",
                            "VideoComponentPlayButton": " _bsl(?: .*)?$",
                            "FeedOptionsPopover": " _b1e(?: .*)?$",
                            "UFICommentLikeCount": " UFICommentLikeButton(?: .*)?$",
                            "UFICommentLink": " _5yxe(?: .*)?$",
                            "ChatTabComposerInputContainer": " _552h(?: .*)?$",
                            "ChatTabHeader": " _15p4(?: .*)?$",
                            "DraftEditor": " _5rp7(?: .*)?$",
                            "ChatSideBarDropDown": " _5vm9(?: .*)?$",
                            "SearchBox": " _539-(?: .*)?$",
                            "ChatSideBarLink": " _55ln(?: .*)?$",
                            "MessengerSearchTypeahead": " _3rh8(?: .*)?$",
                            "NotificationListItem": " _33c(?: .*)?$",
                            "MessageJewelListItem": " messagesContent(?: .*)?$",
                            "Messages_Jewel_Button": " _3eo8(?: .*)?$",
                            "Notifications_Jewel_Button": " _3eo9(?: .*)?$",
                            "snowliftopen": " _342u(?: .*)?$",
                            "NoteTextSeeMoreLink": " _3qd_(?: .*)?$",
                            "fbFeedOptionsPopover": " _1he6(?: .*)?$",
                            "Requests_Jewel_Button": " _3eoa(?: .*)?$",
                            "UFICommentActionLinkAjaxify": " _15-3(?: .*)?$",
                            "UFICommentActionLinkRedirect": " _15-6(?: .*)?$",
                            "UFICommentActionLinkDispatched": " _15-7(?: .*)?$",
                            "UFICommentCloseButton": " _36rj(?: .*)?$",
                            "UFICommentActionsRemovePreview": " _460h(?: .*)?$",
                            "UFICommentActionsReply": " _460i(?: .*)?$",
                            "UFICommentActionsSaleItemMessage": " _460j(?: .*)?$",
                            "UFICommentActionsAcceptAnswer": " _460k(?: .*)?$",
                            "UFICommentActionsUnacceptAnswer": " _460l(?: .*)?$",
                            "UFICommentReactionsLikeLink": " _3-me(?: .*)?$",
                            "UFICommentMenu": " _1-be(?: .*)?$",
                            "UFIMentionsInputFallback": " _289b(?: .*)?$",
                            "UFIMentionsInputComponent": " _289c(?: .*)?$",
                            "UFIMentionsInputProxyInput": " _432z(?: .*)?$",
                            "UFIMentionsInputProxyDummy": " _432-(?: .*)?$",
                            "UFIPrivateReplyLinkMessage": " _14hj(?: .*)?$",
                            "UFIPrivateReplyLinkSeeReply": " _14hk(?: .*)?$",
                            "ChatCloseButton": " _4vu4(?: .*)?$",
                            "ChatTabComposerPhotoUploader": " _13f-(?: .*)?$",
                            "ChatTabComposerGroupPollingButton": " _13f_(?: .*)?$",
                            "ChatTabComposerGames": " _13ga(?: .*)?$",
                            "ChatTabComposerPlan": " _13gb(?: .*)?$",
                            "ChatTabComposerFileUploader": " _13gd(?: .*)?$",
                            "ChatTabStickersButton": " _13ge(?: .*)?$",
                            "ChatTabComposerGifButton": " _13gf(?: .*)?$",
                            "ChatTabComposerEmojiPicker": " _13gg(?: .*)?$",
                            "ChatTabComposerLikeButton": " _13gi(?: .*)?$",
                            "ChatTabComposerP2PButton": " _13gj(?: .*)?$",
                            "ChatTabComposerQuickCam": " _13gk(?: .*)?$",
                            "ChatTabHeaderAudioRTCButton": " _461a(?: .*)?$",
                            "ChatTabHeaderVideoRTCButton": " _461b(?: .*)?$",
                            "ChatTabHeaderOptionsButton": " _461_(?: .*)?$",
                            "ChatTabHeaderAddToThreadButton": " _4620(?: .*)?$",
                            "ReactComposerMediaSprout": " _fk5(?: .*)?$",
                            "UFIReactionsBlingSocialSentenceComments": " _-56(?: .*)?$",
                            "UFIReactionsBlingSocialSentenceSeens": " _2x0l(?: .*)?$",
                            "UFIReactionsBlingSocialSentenceShares": " _2x0m(?: .*)?$",
                            "UFIReactionsBlingSocialSentenceViews": " _-5c(?: .*)?$",
                            "UFIReactionsBlingSocialSentence": " _-5d(?: .*)?$",
                            "UFIReactionsSocialSentence": " _1vaq(?: .*)?$",
                            "VideoFullscreenButton": " _39ip(?: .*)?$",
                            "Tahoe": " _400z(?: .*)?$",
                            "TahoeFromVideoPlayer": " _1vek(?: .*)?$",
                            "TahoeFromVideoLink": " _2-40(?: .*)?$",
                            "TahoeFromPhoto": " _2ju5(?: .*)?$",
                            "FBStoryTrayItem": " _1fvw(?: .*)?$",
                            "Mobile_Feed_Jewel_Button": "#feed_jewel( .+)*",
                            "Mobile_Requests_Jewel_Button": "#requests_jewel( .+)*",
                            "Mobile_Messages_Jewel_Button": "#messages_jewel( .+)*",
                            "Mobile_Notifications_Jewel_Button": "#notifications_jewel( .+)*",
                            "Mobile_Search_Jewel_Button": "#search_jewel( .+)*",
                            "Mobile_Bookmarks_Jewel_Button": "#bookmarks_jewel( .+)*",
                            "Mobile_Feed_UFI_Comment_Button_Permalink": " _l-a(?: .*)?$",
                            "Mobile_Feed_UFI_Comment_Button_Flyout": " _4qeq(?: .*)?$",
                            "Mobile_Feed_UFI_Token_Bar_Flyout": " _4qer(?: .*)?$",
                            "Mobile_Feed_UFI_Token_Bar_Permalink": " _4-09(?: .*)?$",
                            "Mobile_UFI_Share_Button": " _15kr(?: .*)?$",
                            "Mobile_Feed_Photo_Permalink": " _1mh-(?: .*)?$",
                            "Mobile_Feed_Video_Permalink": " _65g_(?: .*)?$",
                            "Mobile_Feed_Profile_Permalink": " _4kk6(?: .*)?$",
                            "Mobile_Feed_Story_Permalink": " _26yo(?: .*)?$",
                            "Mobile_Feed_Page_Permalink": " _4e81(?: .*)?$",
                            "Mobile_Feed_Group_Permalink": " _20u1(?: .*)?$",
                            "Mobile_Feed_Event_Permalink": " _20u0(?: .*)?$",
                            "ProfileIntroCardAddFeaturedMedia": " _30qr(?: .*)?$",
                            "ProfileSectionAbout": " _Interaction__ProfileSectionAbout(?: .*)?$",
                            "ProfileSectionAllRelationships": " _Interaction__ProfileSectionAllRelationships(?: .*)?$",
                            "ProfileSectionAtWork": " _2fnv(?: .*)?$",
                            "ProfileSectionContactBasic": " _Interaction__ProfileSectionContactBasic(?: .*)?$",
                            "ProfileSectionEducation": " _Interaction__ProfileSectionEducation(?: .*)?$",
                            "ProfileSectionOverview": " _Interaction__ProfileSectionOverview(?: .*)?$",
                            "ProfileSectionPlaces": " _Interaction__ProfileSectionPlaces(?: .*)?$",
                            "ProfileSectionYearOverviews": " _Interaction__ProfileSectionYearOverviews(?: .*)?$",
                            "IntlPolyglotHomepage": " _Interaction__IntlPolyglotVoteActivityCardButton(?: .*)?$",
                            "ProtonElementSelection": " _67ft(?: .*)?$"
                        },
                        "interaction_boost": {
                            "SnowliftPrevPager": 0.2,
                            "SnowliftNextPager": 0.2,
                            "ChatSideBarLink": 2,
                            "MessengerSearchTypeahead": 2,
                            "Messages_Jewel_Button": 2.5,
                            "Notifications_Jewel_Button": 1.5,
                            "Tahoe": 30,
                            "ProtonElementSelection": 4
                        },
                        "event_types": {
                            "BlueBarAccountChevronMenu": ["click"],
                            "BlueBarHomeButton": ["click"],
                            "BlueBarProfileLink": ["click"],
                            "ReactComposerSproutMedia": ["click"],
                            "ReactComposerSproutAlbum": ["click"],
                            "ReactComposerSproutNote": ["click"],
                            "ReactComposerSproutLocation": ["click"],
                            "ReactComposerSproutActivity": ["click"],
                            "ReactComposerSproutPeople": ["click"],
                            "ReactComposerSproutLiveVideo": ["click"],
                            "ReactComposerSproutMarkdown": ["click"],
                            "ReactComposerSproutFormattedText": ["click"],
                            "ReactComposerSproutSticker": ["click"],
                            "ReactComposerSproutSponsor": ["click"],
                            "ReactComposerSproutEllipsis": ["click"],
                            "ReactComposerSproutContactYourRepresentative": ["click"],
                            "ReactComposerSproutFunFact": ["click"],
                            "TextExposeSeeMoreLink": ["click"],
                            "SnowliftBigCloseButton": ["click"],
                            "SnowliftPrevPager": ["click"],
                            "SnowliftNextPager": ["click"],
                            "SnowliftFullScreenButton": ["click"],
                            "PrivacySelectorMenu": ["click"],
                            "ReactComposerFeedXSprouts": ["click"],
                            "SproutsComposerStatusTab": ["click"],
                            "SproutsComposerLiveVideoTab": ["click"],
                            "SproutsComposerAlbumTab": ["click"],
                            "composerAudienceSelector": ["click"],
                            "FeedHScrollAttachmentsPrevPager": ["click"],
                            "FeedHScrollAttachmentsNextPager": ["click"],
                            "DockChatTabFlyout": ["click"],
                            "PrivacyLiteJewel": ["click"],
                            "ActorSelector": ["click"],
                            "LegacyMentionsInput": ["click"],
                            "UFIActionLinksEmbedLink": ["click"],
                            "UFIPhotoAttachLink": ["click"],
                            "UFIMentionsInputProxy": ["click"],
                            "UFIMentionsInputDummy": ["click"],
                            "UFIOrderingModeSelector": ["click"],
                            "UFIPager": ["click"],
                            "UFIReplyRow": ["click"],
                            "UFIReplySocialSentence": ["click"],
                            "UFIShareLink": ["click"],
                            "UFIStickerButton": ["click"],
                            "MentionsInput": ["click"],
                            "FantaChatTabRoot": ["click"],
                            "SnowliftViewableRoot": ["click"],
                            "ReactBlueBarJewelButton": ["click"],
                            "UFIReactionsDialogLayerImpl": ["click"],
                            "UFIReactionsLikeLinkImpl": ["click"],
                            "UFIReactionsLinkImplRoot": ["click"],
                            "Reaction": ["click"],
                            "UFIReactionsMenuImpl": ["click"],
                            "UFIReactionsSpatialReactionIconContainer": ["click"],
                            "VideoComponentPlayButton": ["click"],
                            "FeedOptionsPopover": ["click"],
                            "UFICommentLikeCount": ["click"],
                            "UFICommentLink": ["click"],
                            "ChatTabComposerInputContainer": ["click"],
                            "ChatTabHeader": ["click"],
                            "DraftEditor": ["click"],
                            "ChatSideBarDropDown": ["click"],
                            "SearchBox": ["click"],
                            "ChatSideBarLink": ["mouseup"],
                            "MessengerSearchTypeahead": ["click"],
                            "NotificationListItem": ["click"],
                            "MessageJewelListItem": ["click"],
                            "Messages_Jewel_Button": ["click"],
                            "Notifications_Jewel_Button": ["click"],
                            "snowliftopen": ["click"],
                            "NoteTextSeeMoreLink": ["click"],
                            "fbFeedOptionsPopover": ["click"],
                            "Requests_Jewel_Button": ["click"],
                            "UFICommentActionLinkAjaxify": ["click"],
                            "UFICommentActionLinkRedirect": ["click"],
                            "UFICommentActionLinkDispatched": ["click"],
                            "UFICommentCloseButton": ["click"],
                            "UFICommentActionsRemovePreview": ["click"],
                            "UFICommentActionsReply": ["click"],
                            "UFICommentActionsSaleItemMessage": ["click"],
                            "UFICommentActionsAcceptAnswer": ["click"],
                            "UFICommentActionsUnacceptAnswer": ["click"],
                            "UFICommentReactionsLikeLink": ["click"],
                            "UFICommentMenu": ["click"],
                            "UFIMentionsInputFallback": ["click"],
                            "UFIMentionsInputComponent": ["click"],
                            "UFIMentionsInputProxyInput": ["click"],
                            "UFIMentionsInputProxyDummy": ["click"],
                            "UFIPrivateReplyLinkMessage": ["click"],
                            "UFIPrivateReplyLinkSeeReply": ["click"],
                            "ChatCloseButton": ["click"],
                            "ChatTabComposerPhotoUploader": ["click"],
                            "ChatTabComposerGroupPollingButton": ["click"],
                            "ChatTabComposerGames": ["click"],
                            "ChatTabComposerPlan": ["click"],
                            "ChatTabComposerFileUploader": ["click"],
                            "ChatTabStickersButton": ["click"],
                            "ChatTabComposerGifButton": ["click"],
                            "ChatTabComposerEmojiPicker": ["click"],
                            "ChatTabComposerLikeButton": ["click"],
                            "ChatTabComposerP2PButton": ["click"],
                            "ChatTabComposerQuickCam": ["click"],
                            "ChatTabHeaderAudioRTCButton": ["click"],
                            "ChatTabHeaderVideoRTCButton": ["click"],
                            "ChatTabHeaderOptionsButton": ["click"],
                            "ChatTabHeaderAddToThreadButton": ["click"],
                            "ReactComposerMediaSprout": ["click"],
                            "UFIReactionsBlingSocialSentenceComments": ["click"],
                            "UFIReactionsBlingSocialSentenceSeens": ["click"],
                            "UFIReactionsBlingSocialSentenceShares": ["click"],
                            "UFIReactionsBlingSocialSentenceViews": ["click"],
                            "UFIReactionsBlingSocialSentence": ["click"],
                            "UFIReactionsSocialSentence": ["click"],
                            "VideoFullscreenButton": ["click"],
                            "Tahoe": ["click"],
                            "TahoeFromVideoPlayer": ["click"],
                            "TahoeFromVideoLink": ["click"],
                            "TahoeFromPhoto": ["click"],
                            "": ["click"],
                            "FBStoryTrayItem": ["click"],
                            "Mobile_Feed_Jewel_Button": ["click"],
                            "Mobile_Requests_Jewel_Button": ["click"],
                            "Mobile_Messages_Jewel_Button": ["click"],
                            "Mobile_Notifications_Jewel_Button": ["click"],
                            "Mobile_Search_Jewel_Button": ["click"],
                            "Mobile_Bookmarks_Jewel_Button": ["click"],
                            "Mobile_Feed_UFI_Comment_Button_Permalink": ["click"],
                            "Mobile_Feed_UFI_Comment_Button_Flyout": ["click"],
                            "Mobile_Feed_UFI_Token_Bar_Flyout": ["click"],
                            "Mobile_Feed_UFI_Token_Bar_Permalink": ["click"],
                            "Mobile_UFI_Share_Button": ["click"],
                            "Mobile_Feed_Photo_Permalink": ["click"],
                            "Mobile_Feed_Video_Permalink": ["click"],
                            "Mobile_Feed_Profile_Permalink": ["click"],
                            "Mobile_Feed_Story_Permalink": ["click"],
                            "Mobile_Feed_Page_Permalink": ["click"],
                            "Mobile_Feed_Group_Permalink": ["click"],
                            "Mobile_Feed_Event_Permalink": ["click"],
                            "ProfileIntroCardAddFeaturedMedia": ["click"],
                            "ProfileSectionAbout": ["click"],
                            "ProfileSectionAllRelationships": ["click"],
                            "ProfileSectionAtWork": ["click"],
                            "ProfileSectionContactBasic": ["click"],
                            "ProfileSectionEducation": ["click"],
                            "ProfileSectionOverview": ["click"],
                            "ProfileSectionPlaces": ["click"],
                            "ProfileSectionYearOverviews": ["click"],
                            "IntlPolyglotHomepage": ["click"],
                            "ProtonElementSelection": ["click"]
                        },
                        "manual_instrumentation": false,
                        "profile_eager_execution": true,
                        "disable_heuristic": true,
                        "disable_event_profiler": false
                    }, 1726],
                    ["KillabyteProfilerConfig", [], {
                        "htmlProfilerModule": null,
                        "profilerModule": null,
                        "depTypes": {
                            "BL": "bl",
                            "NON_BL": "non-bl"
                        }
                    }, 1145],
                    ["QuicklingConfig", [], {
                        "version": "4207187;0;",
                        "sessionLength": 30,
                        "inactivePageRegex": "^\/(fr\/u\\.php|ads\/|advertising|ac\\.php|ae\\.php|a\\.php|ajax\/emu\/(end|f|h)\\.php|badges\/|comments\\.php|connect\/uiserver\\.php|editalbum\\.php.+add=1|ext\/|feeds\/|help([\/?]|$)|identity_switch\\.php|isconnectivityahumanright\/|intern\/|login\\.php|logout\\.php|sitetour\/homepage_tour\\.php|sorry\\.php|syndication\\.php|webmessenger|\/plugins\/subscribe|lookback|brandpermissions|gameday|pxlcld|comet|worldcup\/map|livemap|work\/admin|([^\/]+\/)?dialog)|legal|\\.pdf$",
                        "badRequestKeys": ["nonce", "access_token", "oauth_token", "xs", "checkpoint_data", "code"],
                        "logRefreshOverhead": false
                    }, 60],
                    ["MarauderConfig", [], {
                        "app_version": "4207187",
                        "gk_enabled": false
                    }, 31],
                    ["ImmediateActiveSecondsConfig", [], {
                        "sampling_rate": 0
                    }, 423],
                    ["MBanzaiConfig", [], {
                        "EXPIRY": 86400000,
                        "MAX_SIZE": 10000,
                        "MAX_WAIT": 30000,
                        "RESTORE_WAIT": 30000,
                        "gks": {
                            "boosted_component": true,
                            "mchannel_jumpstart": true,
                            "platform_oauth_client_events": true,
                            "visibility_tracking": true,
                            "xtrackable_clientview_batch": true,
                            "boosted_pagelikes": true,
                            "gqls_web_logging": true
                        },
                        "blacklist": ["time_spent"]
                    }, 32],
                    ["MSession", [], {
                        "useAngora": false,
                        "logoutURL": "\/logout.php?h=AfepPABFJIPO4QWp&t=1534269818",
                        "push_phase": "C3"
                    }, 52]
                ]);
                new(require("ServerJS"))().handle({});
            }, "ServerJS define", {
                "root": true
            })();
            require("MCoreInit").init({
                "clearMCache": false,
                "deferredResources": ["x2UrK", "aeS7Z", "6DHbD", "lsMwW", "YdT9E", "wqI7T", "FEt5G"],
                "hideLocationBar": true,
                "onafterload": "window.CavalryLogger&&CavalryLogger.getInstance().setTimeStamp(\"t_paint\");;if (window.ExitTime){CavalryLogger.getInstance(\"6589638692853231387-0\").setValue(\"t_exit\", window.ExitTime);};",
                "onload": "",
                "serverJSData": {
                    "elements": [
                        ["__elem_de5177dd_0_0", "u_0_0", 1],
                        ["__elem_921b58ef_0_0", "login_form", 1],
                        ["__elem_7216e2ae_0_0", "email_input_container", 1],
                        ["__elem_e24cb174_0_0", "m_login_password", 1],
                        ["__elem_7216e2ae_0_3", "u_0_1", 1],
                        ["__elem_e03291d5_0_1", "u_0_2", 1],
                        ["__elem_e03291d5_0_0", "u_0_3", 1],
                        ["__elem_2df5b073_0_0", "did-you-forget-your-password-link", 1],
                        ["__elem_7216e2ae_0_1", "u_0_4", 1],
                        ["__elem_be66b106_0_0", "u_0_5", 1],
                        ["__elem_7216e2ae_0_2", "u_0_6", 1],
                        ["__elem_e980dec4_0_0", "signup-button", 1],
                        ["__elem_49f6b607_0_0", "root", 1],
                        ["__elem_eed16c0a_0_0", "u_0_7", 1],
                        ["__elem_a588f507_0_0", "u_0_8", 1],
                        ["__elem_a588f507_0_1", "u_0_9", 1],
                        ["__elem_0cdc66ad_0_0", "u_0_b", 1],
                        ["__elem_0cdc66ad_0_1", "u_0_c", 1]
                    ],
                    "require": [
                        ["MobileZeroRewriteURL", "main", [],
                            [{
                                "regex_matcher": ["^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(\/.*(\\.mp4|\\.hls|\\.flv)(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(\/.*(\\.mp4|\\.hls|\\.flv)(\\?.*)?$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net)(:?[0-9]{0,5})(.*(?:t[0-9]+\\.(?:1997)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net)(:?[0-9]{0,5})(.*(?:t[0-9]+\\.(?:9024)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net)(:?[0-9]{0,5})(.*(?:t[0-9]+\\.(?:10537|11485)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net)(:?[0-9]{0,5})(.*(?:t[0-9]+\\.(?:1997)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net)(:?[0-9]{0,5})(.*(?:t[0-9]+\\.(?:9024)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net)(:?[0-9]{0,5})(.*(?:t[0-9]+\\.(?:10537|11485)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)((?:fbdj1-1|fbdo1-1|fbpn1-1|fbth1-1|fcgk1-1|fcgk11-1|fcgk2-1|fcgk4-1|fcgk4-2|fcgk5-1|fdps1-1|fmdc1-1|fpku4-1|fplm1-1|fpnk1-1|fsoc1-1|fsub5-1|fsub6-1|fsub6-2|fsub6-3|fupg3-1)\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))($|\\?.*$|\/.*$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(\/.*(\\.mp4|\\.hls|\\.flv)(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(\/.*(\\.mp4|\\.hls|\\.flv)(\\?.*)?$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:1997)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:9024)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:10537|11485)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:1997)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:9024)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:10537|11485)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(?:z-1-|z-m-|z-p3-|z-p4-)?([0-9a-zA-Z\\.-]+\\.)(f\\w+-\\w+\\.fna)(\\.fbcdn\\.net(:?[0-9]{0,5}))($|\\?.*$|\/.*$)", "^(https?):\/\/(api|api2|z-m-api|api-read|z-p3-api|z-p4-api|b-api)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})((?:\/method\/user\\.registerPushCallback|\/method\/user\\.confirmContactpointPreconfirmation|\/method\/xconfig\\.fetch|\/method\/mobile\\.gatekeepers|\/method\/user\\.unregisterPushCallback|\/method\/notifications\\.get|\/me\/notification_seen_states|\/method\/auth\\.expireSession|\/method\/auth\\.login|\/method\/bookmarks\\.get|\/me\/messenger_only_account_migrations|\/method\/mobile\\.zeroHeaderRequest|\/method\/user\\.sendMessengerOnlyPhoneConfirmationCode|\/method\/user\\.confirmMessengerOnlyPhone|\/method\/user\\.createMessengerOnlyAccount|\/method\/user\\.bypassLoginWithConfirmedMessengerCredentials|\/method\/user\\.prefillorautocompletecontactpoint|\/method\/user\\.validateregistrationdata|\/method\/user\\.register)(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(?:z-p3-|z-p4-)?(rupload)\\.(?:p\\.|z\\.)?([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})((?:\/fb_video|\/messenger_video|\/messenger_videos)(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(?:z-p3-|z-p4-)?(rupload)\\.(?:p\\.|z\\.)?([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/messenger_image(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(?:z-p3-|z-p4-)?(rupload)\\.(?:p\\.|z\\.)?([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/messenger_gif(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(?:z-p3-|z-p4-)?(rupload)\\.(?:p\\.|z\\.)?([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/messenger_audio(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(?:z-p3-|z-p4-)?(rupload)\\.(?:p\\.|z\\.)?([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/messenger_file(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(?:z-p3-|z-p4-)?(rupload)\\.(?:p\\.|z\\.)?([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(\\w+)\\.(p|z)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(\/.*(\\.mp4|\\.hls|\\.flv)(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(\/.*(\\.mp4|\\.hls|\\.flv)(\\?.*)?$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:1997)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:9024)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:10537|11485)-6($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)))", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:1997)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:9024)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*(?:t[0-9]+\\.(?:10537|11485)-6($|\\?.*$|\/.*$)))", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:0|1|8|9|10|12))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:0|1|8|9|10|12))($|\\?.*$|\/.*$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:2|26|27|28|29))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:2|26|27|28|29))($|\\?.*$|\/.*$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:4))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:4))($|\\?.*$|\/.*$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:21))($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))(.*)(t[^\/-]+-(?:21))($|\\?.*$|\/.*$)", "^(https?):\/\/(z-1-|z-m-|z-p3-|z-p4-|)([0-9a-zA-Z\\.-]+)(?:-[0-9a-zA-Z]+-sonar)?(\\.xx\\.fbcdn\\.net(:?[0-9]{0,5}))($|\\?.*$|\/.*$)", "^(https?):\/\/((z-m-|z-1-)?static\\.xx\\.fbcdn\\.net|(m-)?static\\.ak\\.fbcdn\\.net)(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(?:fbcdn-|fb)[0-9a-zA-Z\\.-]+-a\\.akamaihd\\.net(:?[0-9]{0,5})\/\\w+-ak-\\w+(\/.*(\\.mp4|\\.hls|\\.flv)(\\?.*)?$)", "^(https?):\/\/fbstatic-a\\.akamaihd\\.net(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(?:fbexternal-a\\.akamaihd\\.net|external\\.ak\\.fbcdn\\.net)(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(?:fbcdn-|fb)[0-9a-zA-Z\\.-]+-a\\.akamaihd\\.net(:?[0-9]{0,5})\/\\w+-ak-\\w+($|\\?.*$|\/.*$)", "^(https?):\/\/(?:dragon|profile)\\.ak\\.fbcdn\\.net(:?[0-9]{0,5})\/\\w+-ak-\\w+($|\\?.*$|\/.*$)", "^(https?):\/\/(api|api2|z-m-api|api-read|z-p3-api|z-p4-api)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/me\/message_audios(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/messagevideoattachment(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})((?:\/\/me\/chunked_upload_sessions|\/\/[0-9]+\/chunks|\/v2\\.3\/[0-9]+\/videos)(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/me\/message_images(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/me\/message_animated_images(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/me\/message_files(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/me\/photos(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(graph|graph2|z-m-graph|z-p3-graph|z-p4-graph)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(z-m-|z-1-|z-p3-|z-p4-)?(cdn|attachment|lookaside)\\.fbsbx\\.com(:?[0-9]{0,5})($|(?:\/.*)?(?:\\?(?!.*_nc_ad=z-m.*$)(?=.*oh=.*$).*)$)", "^(https?):\/\/(z-m-|z-1-|z-p3-|z-p4-)?(cdn|attachment|lookaside)\\.fbsbx\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(m|mobile|d|b-m)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})(\/zero\/toggle\/settings\/(?:$|\\?.*$|\/.*$))", "^(https?):\/\/(free|m|mobile|d|b-m)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(www|web|z-m-www|b-www)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(upload|p-upload|z-upload|z-p3-upload|z-p4-upload)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)", "^(https?):\/\/(graph-video|z-graph-video|p-graph-video|z-p3-graph-video|z-p4-graph-video)\\.([0-9a-zA-Z\\.-]*)?facebook\\.com(:?[0-9]{0,5})($|\\?.*$|\/.*$)"],
                                "regex_replacer": ["$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2$3$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/$2xx$4$6", "$1:\/\/z-m-api.$3facebook.com$4$5", "$1:\/\/$2.$3facebook.com$4$5", "$1:\/\/$2.$3facebook.com$4$5", "$1:\/\/$2.$3facebook.com$4$5", "$1:\/\/$2.$3facebook.com$4$5", "$1:\/\/$2.$3facebook.com$4$5", "$1:\/\/$2.$3facebook.com$4$5", "$1:\/\/$2.$4facebook.com$5$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6$7$8", "$1:\/\/$3$4$6", "$1:\/\/static.xx.fbcdn.net$5$6", "$1:\/\/scontent.xx.fbcdn.net$2$3", "$1:\/\/static.xx.fbcdn.net$2$3", "$1:\/\/external.xx.fbcdn.net$2$3", "$1:\/\/scontent.xx.fbcdn.net$2$3", "$1:\/\/scontent.xx.fbcdn.net$2$3", "$1:\/\/api.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/graph.$3facebook.com$4$5", "$1:\/\/$3.fbsbx.com$4$5", "$1:\/\/$3.fbsbx.com$4$5", "$1:\/\/m.$3facebook.com$4$5", "$1:\/\/m.$3facebook.com$4$5", "$1:\/\/www.$3facebook.com$4$5", "$1:\/\/upload.$3facebook.com$4$5", "$1:\/\/graph-video.$3facebook.com$4$5"]
                            }]
                        ],
                        ["BrowserPrefillLogging", "initContactpointFieldLogging", [],
                            [{
                                "contactpointFieldID": "m_login_email",
                                "serverPrefill": ""
                            }]
                        ],
                        ["MLoginController", "initClearCPCross", ["__elem_7216e2ae_0_0"],
                            [{
                                "root": {
                                    "__m": "__elem_7216e2ae_0_0"
                                }
                            }]
                        ],
                        ["MLoginController", "initIncorrectPWErrorMsgLink", ["__elem_2df5b073_0_0"],
                            [{
                                "root": {
                                    "__m": "__elem_2df5b073_0_0"
                                }
                            }]
                        ],
                        ["BrowserPrefillLogging", "initPasswordFieldLogging", [],
                            [{
                                "passwordFieldID": "m_login_password"
                            }]
                        ],
                        ["MLoginView", "disableOnSubmit", ["__elem_921b58ef_0_0", "__elem_7216e2ae_0_1"],
                            [{
                                "__m": "__elem_921b58ef_0_0"
                            }, {
                                "__m": "__elem_7216e2ae_0_1"
                            }]
                        ],
                        ["MLoginController", "initRegButton", ["__elem_7216e2ae_0_2"],
                            [{
                                "root": {
                                    "__m": "__elem_7216e2ae_0_2"
                                },
                                "regURI": "\/reg\/?cid=103",
                                "useRegToLogin": true
                            }]
                        ],
                        ["MLoginController", "initLoginForm", ["__elem_de5177dd_0_0"],
                            [{
                                "root": {
                                    "__m": "__elem_de5177dd_0_0"
                                },
                                "ajaxURI": "#",
                                "rapidFeedbackUri": null,
                                "clearOnDelete": false,
                                "listenKeyDown": false,
                                "isTwoStepsLogin": false,
                                "passwordStepDelayMilliSeconds": 1000,
                                "isActionLoggingEnabled": true,
                                "isEarlyCPCheckEnabled": false,
                                "onErrorRegURI": "\/r.php",
                                "shouldNotAutoFocusPasswordField": false,
                                "shouldAutoLandOnStep2": false,
                                "shouldClearPasswordIfPrefilledCPChanged": true,
                                "shouldEnableOneStepLoginForPrefill": false,
                                "shouldAutoSubmitWhenPrefilledStep1": false,
                                "shouldAutoSubmitWhenPrefilledStep2": false,
                                "shouldEnableOneStepLoginOnStepTwo": false,
                                "shouldClearPasswordIfOnlyPasswordPrefilled": true,
                                "shouldRenderBoxedProfilePicDesign": true,
                                "shouldShowProfilePicWithCP": false,
                                "shouldEnableOneTimePassword": true,
                                "shouldEnableScrollToError": false,
                                "shouldEnableInlineError": false,
                                "shouldEnableEditableCPDesign": true,
                                "shouldCallServerOnEmptyCP": false,
                                "isWithSafariFix": true,
                                "shouldEnableOTPWithoutRedirection": false,
                                "shouldPrefillHeaderJio": false,
                                "shouldProcessUserConsentForTokenHeader": false,
                                "shouldShowBlankCPPWErrorMsgWithLink": false,
                                "shouldShowBlankCPPWErrorMsgNoLink": false,
                                "shouldShowBlankPWValidCPErrorMsg": false,
                                "shouldShowBlankPWValidCPErrorMsgNonAccurateExposure": false,
                                "shouldSeparateIncorrectPWCTAFromErrorMSG": false
                            }]
                        ],
                        ["MPasswordPlainTextToggle", "init", ["__elem_e24cb174_0_0", "__elem_7216e2ae_0_3", "__elem_e03291d5_0_0", "__elem_e03291d5_0_1"],
                            [{
                                "__m": "__elem_e24cb174_0_0"
                            }, {
                                "__m": "__elem_7216e2ae_0_3"
                            }, {
                                "__m": "__elem_e03291d5_0_0"
                            }, {
                                "__m": "__elem_e03291d5_0_1"
                            }]
                        ],
                        ["ServiceWorkerLoginAndLogoutListener", "listen", ["__elem_be66b106_0_0"],
                            [{
                                "__m": "__elem_be66b106_0_0"
                            }, "login", "\/sw?s=push", 612424062191227]
                        ],
                        ["MTouchable"],
                        ["MBlockingTouchable", "init", ["__elem_e980dec4_0_0"],
                            [{
                                "__m": "__elem_e980dec4_0_0"
                            }]
                        ],
                        ["AccessibilityWebVirtualCursorClickLogger", "init", ["__elem_49f6b607_0_0"],
                            [
                                [{
                                    "__m": "__elem_49f6b607_0_0"
                                }]
                            ]
                        ],
                        ["MScrollPositionSaver"],
                        ["MLogoutClearCache"],
                        ["LoadingIndicator", "init", ["__elem_eed16c0a_0_0", "__elem_a588f507_0_0", "__elem_a588f507_0_1"],
                            [{
                                "__m": "__elem_eed16c0a_0_0"
                            }, {
                                "__m": "__elem_a588f507_0_0"
                            }, {
                                "__m": "__elem_a588f507_0_1"
                            }]
                        ],
                        ["MPageError"],
                        ["MPageHeaderAccessibility"],
                        ["MBlockingTouchable", "init", ["__elem_0cdc66ad_0_0"],
                            [{
                                "__m": "__elem_0cdc66ad_0_0"
                            }]
                        ],
                        ["MBlockingTouchable", "init", ["__elem_0cdc66ad_0_1"],
                            [{
                                "__m": "__elem_0cdc66ad_0_1"
                            }]
                        ],
                        ["MLoadingIndicator", "init", [],
                            ["u_0_a"]
                        ],
                        ["MPrelude"],
                        ["CavalryLoggerImpl", "startInstrumentation", [],
                            []
                        ],
                        ["LogHistoryListeners"],
                        ["Artillery"],
                        ["ScriptPath", "set", [],
                            ["\/wap\/index.php", "0f4ef985", {
                                "imp_id": "98b16cbb",
                                "ef_page": null
                            }]
                        ],
                        ["MLogging", "main", [],
                            [{
                                "refid": 8
                            }]
                        ],
                        ["RemoteDevice", "init", [],
                            []
                        ],
                        ["MModalDialogInit"],
                        ["MVerifyCache", "main", [],
                            [{
                                "viewer": 0
                            }]
                        ],
                        ["EventProfiler"],
                        ["ScriptPathLogger", "startLogging", [],
                            []
                        ],
                        ["MTimeSpentBitArrayLogger", "init", [],
                            ["m"]
                        ],
                        ["MCommentViewportTracking", "singleton", [],
                            [{
                                "enabled": true,
                                "debug_console": false,
                                "debug_html": false,
                                "idle_timeout": 5000,
                                "min_duration_to_log": 100,
                                "min_visible_size": 200
                            }]
                        ],
                        ["NavigationMetrics"],
                        ["PerfXLogger"],
                        ["ServiceWorkerURLCleaner", "removeRedirectID", [],
                            []
                        ]
                    ]
                },
                "isWildeWeb": false,
                "isFacewebAndroid": false,
                "ixData": {},
                "bxData": {},
                "gkxData": {
                    "AT5tMpZqIKh0vdvJexCKKhPqDfMAWQPHLQnR8CgtajZUMLAZP8rj8YnSD9bEFc4BrmsaxTBmOCxn2mR6tM_ew1hH": {
                        "result": false,
                        "hash": "AT7Lov0pGZsdvtlH"
                    },
                    "AT7zMB0I7eORfH-UodO4y3BTPg5wOO8T247ZMNn2q5-aNcyAQUvzZrGn32ptMehFmO1oqnCJmh_zFD3-bdTI6XU3_0z7OLdKJrGgHtrOitBdeg": {
                        "result": false,
                        "hash": "AT5ibrqYvkvMY8Jc"
                    },
                    "AT4miIiW4pJzE0dukYVRr93bo-U7aeRzegmes3xLz6J7QfAO9xBCVDCcWNxQBaSegngcbU8UJ8KqD-c2mDX0kNsMkP4Db418yITqzzh_hAbRIA": {
                        "result": false,
                        "hash": "AT6BGgZ-HzhabfG9"
                    },
                    "AT68bJwSI-83elN-7JSMMH9zt32KbiF6pW-XMlf6NViAJ3CbAk_16Vq8cK1tl1029_ApvFwINR8hmoci3nMKFTDhDCBp1wrvYQbOKq0pCjZpqA": {
                        "result": false,
                        "hash": "AT6velfNK2kFp6cp"
                    },
                    "AT6vIKc4yvpLzvCe00DDqmWnCcWW9gg6lvyzBsK0MPzrJqNmyZ-lzLSw8lY20YNrZBEF7JSPcBJS9N9bCmn1zMDUn2EIk_0tdJz3AHqh5jmikg": {
                        "result": false,
                        "hash": "AT6PbYVsmGMuhUQa"
                    },
                    "AT676eqa9o_v7kGGM53Nfaq6v7ZzAZW1E6NXkuIXW-8sM0N4DkZ16pxYoDT5UIQfy6xorIGXMlqtYgTSAc6F7oiK": {
                        "result": true,
                        "hash": "AT7wHeGjfak22rOC"
                    },
                    "AT5TADJ4IDqkBvMHj8JLNylXXgmWmvOXJO-tTCuV9i3mkXK-zBXm3JkLm3k6qxbTjLpJmVr_K5j2KZs32AccQJgX": {
                        "result": false,
                        "hash": "AT6EBb0bJILKAwnS"
                    },
                    "AT4kYIk7PhRqUACJJM8qs58t-WNCoM2ZYe35b1xv03xf3OtmC7RfXVIT9hWB6yTOgfA": {
                        "result": false,
                        "hash": "AT5gY_HYVxnH12v4"
                    },
                    "AT42vHZv2FMRQFxjYy8soPYLMZQ4FvEb3npoHjDNtK5L_ed7xyu66vqbi4snBVFxLSGN0ZKY0U-z6rBE6MS3Ht3lEToi6aqMBaQBAYDf8hAjMw": {
                        "result": false,
                        "hash": "AT67d8_BQN0oyitg"
                    },
                    "AT64OjP4oVuvstFjzbDT-bVZiPbiojG0zyjbyWGW5xqhWd5PV8lOQAaU0boVR7zf5v2SUGNGfZkpE7I19ksV-nLimTCJ0AgU9faj1FK9VMmZbw": {
                        "result": false,
                        "hash": "AT4wTBKNsd-bLhG3"
                    },
                    "AT5O8xsR5x0ELlZ5jOE3X5-ehVC3uoPqq660HQDL4w9wKwvRm4MKxHk4lF9KQ7mHHhkAK-AiXe4wZn4Y6p5yGdCP": {
                        "result": false,
                        "hash": "AT4ccnNJCpJgvhgx"
                    },
                    "AT7ImPMHuxZIJZ136ME7VyraMwtCKryQmyrFHtgzHkf8ddy4a6_xWA51xIkynmusmXrOGBFVkNSaxGsbLCgQTZHL": {
                        "result": false,
                        "hash": "AT4kX52xPt1BEJv6"
                    }
                },
                "qexData": {},
                "bootloadable": {
                    "BanzaiODS": {
                        "resources": ["bYi7r"],
                        "module": 1
                    },
                    "GeneratedPackerUtils": {
                        "resources": ["uYbVb", "qlimw"],
                        "module": 1
                    },
                    "SnappyCompressUtil": {
                        "resources": ["J5xSl"],
                        "module": 1
                    },
                    "GeneratedArtilleryUserTimingSink": {
                        "resources": ["uYbVb", "9Zaf3", "sGe+Z", "Hx+az"],
                        "module": 1
                    },
                    "Banzai": {
                        "resources": [],
                        "module": 1
                    },
                    "BanzaiStream": {
                        "resources": ["J5xSl", "bYi7r", "ZU1ro"],
                        "module": 1
                    },
                    "PerfXSharedFields": {
                        "resources": ["wqI7T"],
                        "module": 1
                    },
                    "ResourceTimingBootloaderHelper": {
                        "resources": ["wqI7T"],
                        "module": 1
                    },
                    "TimeSliceHelper": {
                        "resources": ["GefKK"],
                        "module": 1
                    },
                    "TimeSliceInteractionsLiteTypedLogger": {
                        "resources": ["bYi7r", "FHtgt"],
                        "module": 1
                    },
                    "WebSpeedInteractionsTypedLogger": {
                        "resources": ["bYi7r", "4LL\/S"],
                        "module": 1
                    }
                },
                "resource_map": {
                    "uYbVb": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yh\/r\/Vs01pkrhf9S.js",
                        "crossOrigin": 1
                    },
                    "qlimw": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yb\/r\/bIkOJ3EDb-E.js",
                        "crossOrigin": 1
                    },
                    "9Zaf3": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yv\/r\/5ka10Uff-_R.js",
                        "crossOrigin": 1
                    },
                    "sGe+Z": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yJ\/r\/-sDNioLKB_z.js",
                        "crossOrigin": 1
                    },
                    "Hx+az": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yz\/r\/bza1TvaqddI.js",
                        "crossOrigin": 1
                    },
                    "aeS7Z": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yO\/r\/8QMiZq_4Zx2.js",
                        "crossOrigin": 1
                    },
                    "lsMwW": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3i-ZE4\/y4\/l\/id_ID\/jWIUrJ3aT7i.js",
                        "crossOrigin": 1
                    },
                    "YdT9E": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iTj24\/yy\/l\/id_ID\/MKSQgW9fa5o.js",
                        "crossOrigin": 1
                    },
                    "ZU1ro": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yq\/r\/708Ezmm99ay.js",
                        "crossOrigin": 1
                    },
                    "wqI7T": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yY\/r\/Z9r5AzoVIbG.js",
                        "crossOrigin": 1
                    },
                    "GefKK": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yp\/r\/-TdHnkGS4tZ.js",
                        "crossOrigin": 1
                    },
                    "FHtgt": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yd\/r\/rlVu09x5_nO.js",
                        "crossOrigin": 1
                    },
                    "4LL\/S": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yA\/r\/rw8eejqoJci.js",
                        "crossOrigin": 1
                    },
                    "FEt5G": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yo\/r\/2p2n-4YaSvj.js",
                        "crossOrigin": 1
                    }
                }
            });